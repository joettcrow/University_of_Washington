//package edu.uw.jtc;
//
//
//import org.junit.runner.RunWith;
//import org.junit.runners.Suite;
//import test.*;
//
//@RunWith(Suite.class)
//@Suite.SuiteClasses({
//        AccountTest.class,
//        AccountManagerTest.class,
//        DaoTest.class,
//        BrokerTest.class,
//        PrivateMessageCodecTest.class})
//public class TestSuite{
//}
