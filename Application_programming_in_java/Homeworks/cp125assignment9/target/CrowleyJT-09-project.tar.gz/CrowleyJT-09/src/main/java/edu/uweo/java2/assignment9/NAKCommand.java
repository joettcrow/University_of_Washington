package edu.uweo.java2.assignment9;

/**
 * It's a nak command, it does things, well one thing nak thing
 * @author jcrowley
 */
public class NAKCommand {
}
