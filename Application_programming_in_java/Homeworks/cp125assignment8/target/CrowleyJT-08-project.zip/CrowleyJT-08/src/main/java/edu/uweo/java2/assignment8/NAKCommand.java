package edu.uweo.java2.assignment8;

/**
 * @author jcrowley
 */

public class NAKCommand {
}
